package method;

/**
 * 查看字节码指令练习1 赋值和加1
 */
public class Demo0 {
    public static void main(String[] args) {
        int i = 0;
        int j = i + 1;
    }
}
