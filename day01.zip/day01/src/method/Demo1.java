package method;

/**
 * 查看字节码指令练习2 ++
 */
public class Demo1 {
    public static void main(String[] args) {
        int i=0;
        i = i++;

        System.out.println(i);
    }
}
