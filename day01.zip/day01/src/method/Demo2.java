package method;
/**
 * 查看字节码指令练习3   ++  +1 和 +=1
 */
public class Demo2 {
    public static void main(String[] args) {
        int i=0,j=0,k=0;
        i++;
        j = j + 1;
        k += 1;
    }
}
