package arthas;

/**
 * arthas测试案例
 */
public class Demo {
    public static void main(String[] args) throws InterruptedException {
        while(true){
            Thread.sleep(1000L);
        }
    }
}
