package constantpool;

/**
 * 常量池测试案例
 */
public class ConstantPoolTest {
    public static final String a1 = "我爱北京天安门";
    public static final String a2 = "我爱北京天安门";
    public static void main(String[] args) {
        ConstantPoolTest constantPoolTest = new ConstantPoolTest();
    }
}
