package arthas;

public class Demo {
    public static void main(String[] args) throws InterruptedException {
        while(true){
            Thread.sleep(1000L);
        }
    }
}
