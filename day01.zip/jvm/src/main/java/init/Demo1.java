package init;

public class Demo1 {
    static {
        value = 2;
    }
    public static int value = 1;

    public static void main(String[] args) {

    }
}

class Demo1_1{
    static {
        System.out.println("1_1");
    }
}




