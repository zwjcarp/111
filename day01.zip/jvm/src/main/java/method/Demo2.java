package method;

public class Demo2 {
    public static void main(String[] args) {
        int i = 1;
    }
}
