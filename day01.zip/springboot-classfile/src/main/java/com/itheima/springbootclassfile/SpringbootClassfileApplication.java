package com.itheima.springbootclassfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootClassfileApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootClassfileApplication.class, args);
    }

}
