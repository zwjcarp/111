package com.itheima.springbootclassfile.pojo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserVO {
    int id;
    String detail;

}
